--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE harjoitus3;
--
-- Name: harjoitus3; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE harjoitus3 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Finnish_Finland.1252';


ALTER DATABASE harjoitus3 OWNER TO postgres;

\connect harjoitus3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: asennettu_kortti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.asennettu_kortti (
    asennus_id integer NOT NULL,
    sarjanumero character varying(50) NOT NULL,
    kortti_id integer NOT NULL
);


ALTER TABLE public.asennettu_kortti OWNER TO postgres;

--
-- Name: asennettu_kortti_asennus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.asennettu_kortti_asennus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.asennettu_kortti_asennus_id_seq OWNER TO postgres;

--
-- Name: asennettu_kortti_asennus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.asennettu_kortti_asennus_id_seq OWNED BY public.asennettu_kortti.asennus_id;


--
-- Name: elakkeella; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.elakkeella (
    nimi character varying(30) NOT NULL,
    alkamispaiva date NOT NULL
);


ALTER TABLE public.elakkeella OWNER TO postgres;

--
-- Name: kortti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kortti (
    kortti_id integer NOT NULL,
    valmistaja_id integer NOT NULL,
    tyyppi character varying(20) NOT NULL,
    tuotenimi character varying(30) NOT NULL
);


ALTER TABLE public.kortti OWNER TO postgres;

--
-- Name: TABLE kortti; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.kortti IS 'Adapters added to the computer';


--
-- Name: COLUMN kortti.tuotenimi; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.kortti.tuotenimi IS 'Product name of the adapter eg. Radeon 6300';


--
-- Name: kortti_kortti_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kortti_kortti_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kortti_kortti_id_seq OWNER TO postgres;

--
-- Name: kortti_kortti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kortti_kortti_id_seq OWNED BY public.kortti.kortti_id;


--
-- Name: korttityyppi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.korttityyppi (
    tyyppi character varying(20) NOT NULL
);


ALTER TABLE public.korttityyppi OWNER TO postgres;

--
-- Name: TABLE korttityyppi; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.korttityyppi IS 'For the UI drop down list';


--
-- Name: lainaus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lainaus (
    lainausnumero integer NOT NULL,
    opiskelijanumero character varying(8) NOT NULL,
    sarjanumero character varying(50) NOT NULL,
    lainauspaiva date NOT NULL,
    palautuspaiva date
);


ALTER TABLE public.lainaus OWNER TO postgres;

--
-- Name: opiskelija; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opiskelija (
    opiskelijanumero character varying(8) NOT NULL,
    nimi character varying(30) NOT NULL,
    etunimi character varying(20) NOT NULL,
    sukunimi character varying(20) NOT NULL,
    puhelin character varying(15),
    sahkoposti character varying(50),
    postinumero character varying(10) NOT NULL,
    postitoimipaikka character varying(30) NOT NULL,
    jakeluosoite character varying(30) NOT NULL,
    valokuva bytea
);


ALTER TABLE public.opiskelija OWNER TO postgres;

--
-- Name: TABLE opiskelija; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.opiskelija IS 'Basic student information';


--
-- Name: tietokone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tietokone (
    sarjanumero character varying(50) NOT NULL,
    mallinimi character varying(30) NOT NULL
);


ALTER TABLE public.tietokone OWNER TO postgres;

--
-- Name: lainassa; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.lainassa AS
 SELECT tietokone.sarjanumero,
    tietokone.mallinimi,
    opiskelija.sukunimi,
    opiskelija.etunimi,
    opiskelija.opiskelijanumero,
    opiskelija.nimi AS "ryhmä"
   FROM public.tietokone,
    public.opiskelija,
    public.lainaus
  WHERE (((opiskelija.opiskelijanumero)::text = (lainaus.opiskelijanumero)::text) AND ((tietokone.sarjanumero)::text = (lainaus.sarjanumero)::text) AND (lainaus.palautuspaiva IS NULL));


ALTER TABLE public.lainassa OWNER TO postgres;

--
-- Name: lainaus_lainausnumero_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lainaus_lainausnumero_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lainaus_lainausnumero_seq OWNER TO postgres;

--
-- Name: lainaus_lainausnumero_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lainaus_lainausnumero_seq OWNED BY public.lainaus.lainausnumero;


--
-- Name: levypaivitys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.levypaivitys (
    paivitys_id integer NOT NULL,
    sarjanumero character varying(50) NOT NULL,
    lisays boolean NOT NULL,
    levytila integer NOT NULL
);


ALTER TABLE public.levypaivitys OWNER TO postgres;

--
-- Name: COLUMN levypaivitys.lisays; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.levypaivitys.lisays IS 'True if more disks added, false when replaced with a new disk';


--
-- Name: COLUMN levypaivitys.levytila; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.levypaivitys.levytila IS 'Amount of storage space added or replaced in GB';


--
-- Name: levypaivitys_paivitys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.levypaivitys_paivitys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.levypaivitys_paivitys_id_seq OWNER TO postgres;

--
-- Name: levypaivitys_paivitys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.levypaivitys_paivitys_id_seq OWNED BY public.levypaivitys.paivitys_id;


--
-- Name: malli; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.malli (
    mallinimi character varying(30) NOT NULL,
    valmistaja_id integer NOT NULL,
    cpu character varying(20) NOT NULL,
    hdd integer NOT NULL,
    ram integer NOT NULL
);


ALTER TABLE public.malli OWNER TO postgres;

--
-- Name: COLUMN malli.hdd; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.malli.hdd IS 'Amount in GB';


--
-- Name: COLUMN malli.ram; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.malli.ram IS 'Amount in GB';


--
-- Name: ram_paivitys; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ram_paivitys (
    paivitys_id integer NOT NULL,
    sarjanumero character varying(50) NOT NULL,
    lisays integer NOT NULL
);


ALTER TABLE public.ram_paivitys OWNER TO postgres;

--
-- Name: COLUMN ram_paivitys.lisays; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.ram_paivitys.lisays IS 'Amount of RAM added in GB';


--
-- Name: ram_paivitys_paivitys_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ram_paivitys_paivitys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ram_paivitys_paivitys_id_seq OWNER TO postgres;

--
-- Name: ram_paivitys_paivitys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ram_paivitys_paivitys_id_seq OWNED BY public.ram_paivitys.paivitys_id;


--
-- Name: ryhma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ryhma (
    nimi character varying(30) NOT NULL,
    vastuuopettaja character varying(30) NOT NULL
);


ALTER TABLE public.ryhma OWNER TO postgres;

--
-- Name: TABLE ryhma; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.ryhma IS 'Table is for the UI to populate drop down list for Opiskelija window / tab';


--
-- Name: toissa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.toissa (
    nimi character varying(30) NOT NULL,
    alkamispaiva date NOT NULL
);


ALTER TABLE public.toissa OWNER TO postgres;

--
-- Name: valmistaja; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.valmistaja (
    valmistaja_id integer NOT NULL,
    valmistajan_nimi character varying(30) NOT NULL
);


ALTER TABLE public.valmistaja OWNER TO postgres;

--
-- Name: TABLE valmistaja; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.valmistaja IS 'Table is intended to populate a drop down list in the UI';


--
-- Name: valmistaja_valmistaja_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.valmistaja_valmistaja_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.valmistaja_valmistaja_id_seq OWNER TO postgres;

--
-- Name: valmistaja_valmistaja_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.valmistaja_valmistaja_id_seq OWNED BY public.valmistaja.valmistaja_id;


--
-- Name: asennettu_kortti asennus_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asennettu_kortti ALTER COLUMN asennus_id SET DEFAULT nextval('public.asennettu_kortti_asennus_id_seq'::regclass);


--
-- Name: kortti kortti_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kortti ALTER COLUMN kortti_id SET DEFAULT nextval('public.kortti_kortti_id_seq'::regclass);


--
-- Name: lainaus lainausnumero; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lainaus ALTER COLUMN lainausnumero SET DEFAULT nextval('public.lainaus_lainausnumero_seq'::regclass);


--
-- Name: levypaivitys paivitys_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.levypaivitys ALTER COLUMN paivitys_id SET DEFAULT nextval('public.levypaivitys_paivitys_id_seq'::regclass);


--
-- Name: ram_paivitys paivitys_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ram_paivitys ALTER COLUMN paivitys_id SET DEFAULT nextval('public.ram_paivitys_paivitys_id_seq'::regclass);


--
-- Name: valmistaja valmistaja_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.valmistaja ALTER COLUMN valmistaja_id SET DEFAULT nextval('public.valmistaja_valmistaja_id_seq'::regclass);


--
-- Data for Name: asennettu_kortti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.asennettu_kortti (asennus_id, sarjanumero, kortti_id) FROM stdin;
\.
COPY public.asennettu_kortti (asennus_id, sarjanumero, kortti_id) FROM '$$PATH$$/3412.dat';

--
-- Data for Name: elakkeella; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.elakkeella (nimi, alkamispaiva) FROM stdin;
\.
COPY public.elakkeella (nimi, alkamispaiva) FROM '$$PATH$$/3422.dat';

--
-- Data for Name: kortti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kortti (kortti_id, valmistaja_id, tyyppi, tuotenimi) FROM stdin;
\.
COPY public.kortti (kortti_id, valmistaja_id, tyyppi, tuotenimi) FROM '$$PATH$$/3408.dat';

--
-- Data for Name: korttityyppi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.korttityyppi (tyyppi) FROM stdin;
\.
COPY public.korttityyppi (tyyppi) FROM '$$PATH$$/3404.dat';

--
-- Data for Name: lainaus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lainaus (lainausnumero, opiskelijanumero, sarjanumero, lainauspaiva, palautuspaiva) FROM stdin;
\.
COPY public.lainaus (lainausnumero, opiskelijanumero, sarjanumero, lainauspaiva, palautuspaiva) FROM '$$PATH$$/3420.dat';

--
-- Data for Name: levypaivitys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.levypaivitys (paivitys_id, sarjanumero, lisays, levytila) FROM stdin;
\.
COPY public.levypaivitys (paivitys_id, sarjanumero, lisays, levytila) FROM '$$PATH$$/3414.dat';

--
-- Data for Name: malli; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.malli (mallinimi, valmistaja_id, cpu, hdd, ram) FROM stdin;
\.
COPY public.malli (mallinimi, valmistaja_id, cpu, hdd, ram) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: opiskelija; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opiskelija (opiskelijanumero, nimi, etunimi, sukunimi, puhelin, sahkoposti, postinumero, postitoimipaikka, jakeluosoite, valokuva) FROM stdin;
\.
COPY public.opiskelija (opiskelijanumero, nimi, etunimi, sukunimi, puhelin, sahkoposti, postinumero, postitoimipaikka, jakeluosoite, valokuva) FROM '$$PATH$$/3418.dat';

--
-- Data for Name: ram_paivitys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ram_paivitys (paivitys_id, sarjanumero, lisays) FROM stdin;
\.
COPY public.ram_paivitys (paivitys_id, sarjanumero, lisays) FROM '$$PATH$$/3416.dat';

--
-- Data for Name: ryhma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ryhma (nimi, vastuuopettaja) FROM stdin;
\.
COPY public.ryhma (nimi, vastuuopettaja) FROM '$$PATH$$/3417.dat';

--
-- Data for Name: tietokone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tietokone (sarjanumero, mallinimi) FROM stdin;
\.
COPY public.tietokone (sarjanumero, mallinimi) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: toissa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.toissa (nimi, alkamispaiva) FROM stdin;
\.
COPY public.toissa (nimi, alkamispaiva) FROM '$$PATH$$/3421.dat';

--
-- Data for Name: valmistaja; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.valmistaja (valmistaja_id, valmistajan_nimi) FROM stdin;
\.
COPY public.valmistaja (valmistaja_id, valmistajan_nimi) FROM '$$PATH$$/3406.dat';

--
-- Name: asennettu_kortti_asennus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.asennettu_kortti_asennus_id_seq', 1, false);


--
-- Name: kortti_kortti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kortti_kortti_id_seq', 1, false);


--
-- Name: lainaus_lainausnumero_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lainaus_lainausnumero_seq', 3, true);


--
-- Name: levypaivitys_paivitys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.levypaivitys_paivitys_id_seq', 1, false);


--
-- Name: ram_paivitys_paivitys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ram_paivitys_paivitys_id_seq', 1, false);


--
-- Name: valmistaja_valmistaja_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.valmistaja_valmistaja_id_seq', 2, true);


--
-- Name: elakkeella PK_elakkeella; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.elakkeella
    ADD CONSTRAINT "PK_elakkeella" PRIMARY KEY (nimi);


--
-- Name: toissa PK_toissa; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.toissa
    ADD CONSTRAINT "PK_toissa" PRIMARY KEY (nimi);


--
-- Name: asennettu_kortti asennettu_kortti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asennettu_kortti
    ADD CONSTRAINT asennettu_kortti_pk PRIMARY KEY (asennus_id);


--
-- Name: kortti kortti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kortti
    ADD CONSTRAINT kortti_pk PRIMARY KEY (kortti_id);


--
-- Name: korttityyppi korttityyppi_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.korttityyppi
    ADD CONSTRAINT korttityyppi_pk PRIMARY KEY (tyyppi);


--
-- Name: lainaus lainaus_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lainaus
    ADD CONSTRAINT lainaus_pk PRIMARY KEY (lainausnumero);


--
-- Name: levypaivitys levypaivitys_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.levypaivitys
    ADD CONSTRAINT levypaivitys_pk PRIMARY KEY (paivitys_id);


--
-- Name: malli malli_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.malli
    ADD CONSTRAINT malli_pk PRIMARY KEY (mallinimi);


--
-- Name: opiskelija opiskelija_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opiskelija
    ADD CONSTRAINT opiskelija_pk PRIMARY KEY (opiskelijanumero);


--
-- Name: ram_paivitys ram_paivitys_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ram_paivitys
    ADD CONSTRAINT ram_paivitys_pk PRIMARY KEY (paivitys_id);


--
-- Name: ryhma ryhma_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ryhma
    ADD CONSTRAINT ryhma_pk PRIMARY KEY (nimi);


--
-- Name: tietokone tietokone_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tietokone
    ADD CONSTRAINT tietokone_pk PRIMARY KEY (sarjanumero);


--
-- Name: valmistaja valmistaja_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.valmistaja
    ADD CONSTRAINT valmistaja_pk PRIMARY KEY (valmistaja_id);


--
-- Name: asennettu_kortti kortti_asennettu_kortti_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asennettu_kortti
    ADD CONSTRAINT kortti_asennettu_kortti_fk FOREIGN KEY (kortti_id) REFERENCES public.kortti(kortti_id);


--
-- Name: kortti korttityyppi_kortti_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kortti
    ADD CONSTRAINT korttityyppi_kortti_fk FOREIGN KEY (tyyppi) REFERENCES public.korttityyppi(tyyppi);


--
-- Name: tietokone malli_tietokone_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tietokone
    ADD CONSTRAINT malli_tietokone_fk FOREIGN KEY (mallinimi) REFERENCES public.malli(mallinimi);


--
-- Name: lainaus opiskelija_lainaus_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lainaus
    ADD CONSTRAINT opiskelija_lainaus_fk FOREIGN KEY (opiskelijanumero) REFERENCES public.opiskelija(opiskelijanumero);


--
-- Name: opiskelija ryhma_opiskelija_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opiskelija
    ADD CONSTRAINT ryhma_opiskelija_fk FOREIGN KEY (nimi) REFERENCES public.ryhma(nimi);


--
-- Name: asennettu_kortti tietokone_asennettu_kortti_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asennettu_kortti
    ADD CONSTRAINT tietokone_asennettu_kortti_fk FOREIGN KEY (sarjanumero) REFERENCES public.tietokone(sarjanumero);


--
-- Name: lainaus tietokone_lainaus_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lainaus
    ADD CONSTRAINT tietokone_lainaus_fk FOREIGN KEY (sarjanumero) REFERENCES public.tietokone(sarjanumero);


--
-- Name: levypaivitys tietokone_levypaivitys_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.levypaivitys
    ADD CONSTRAINT tietokone_levypaivitys_fk FOREIGN KEY (sarjanumero) REFERENCES public.tietokone(sarjanumero);


--
-- Name: ram_paivitys tietokone_ram_paivitys_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ram_paivitys
    ADD CONSTRAINT tietokone_ram_paivitys_fk FOREIGN KEY (sarjanumero) REFERENCES public.tietokone(sarjanumero);


--
-- Name: kortti valmistaja_kortti_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kortti
    ADD CONSTRAINT valmistaja_kortti_fk FOREIGN KEY (valmistaja_id) REFERENCES public.valmistaja(valmistaja_id);


--
-- Name: malli valmistaja_malli_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.malli
    ADD CONSTRAINT valmistaja_malli_fk FOREIGN KEY (valmistaja_id) REFERENCES public.valmistaja(valmistaja_id);


--
-- PostgreSQL database dump complete
--

